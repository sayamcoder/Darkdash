// setup/multer-config.js
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Define the paths for our upload directories
const imageDir = path.join(__dirname, '../public/uploads');
const digitalDir = path.join(__dirname, '../public/digital_files');

// --- THIS IS THE KEY FIX ---
// Ensure these directories exist before the server even starts.
// The { recursive: true } option creates parent directories if they don't exist.
fs.mkdirSync(imageDir, { recursive: true });
fs.mkdirSync(digitalDir, { recursive: true });
// ----------------------------

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        // Sort files into the correct, now-guaranteed-to-exist folders
        if (file.fieldname === 'digitalFile') {
            cb(null, digitalDir);
        } else { // 'productImage'
            cb(null, imageDir);
        }
    },
    filename: (req, file, cb) => {
        // Create a safe, unique filename
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, `${file.fieldname}-${uniqueSuffix}${path.extname(file.originalname)}`);
    }
});

// A function to check that the file type is allowed (optional but good practice)
function fileFilter(req, file, cb) {
    // You can add more checks here if you want
    if (file.fieldname === 'productImage') {
        if (!file.originalname.match(/\.(jpg|jpeg|png|gif|webp)$/)) {
            return cb(new Error('Only image files are allowed for Product Image!'), false);
        }
    }
    cb(null, true);
}

// Export the configured multer instance
const upload = multer({ storage: storage, fileFilter: fileFilter }).fields([
    { name: 'productImage', maxCount: 1 },
    { name: 'digitalFile', maxCount: 1 }
]);

module.exports = upload;