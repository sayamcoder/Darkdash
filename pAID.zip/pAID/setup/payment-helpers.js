// setup/payment-helpers.js
const crypto = require('crypto');

// --- JAZZCASH HELPER ---
function getJazzCashSecureHash(dataObject) {
    const integritySalt = process.env.JAZZCASH_INTEGRITY_SALT;
    
    // Sort the keys alphabetically
    const sortedKeys = Object.keys(dataObject).sort();

    let stringToHash = integritySalt;
    sortedKeys.forEach(key => {
        stringToHash += `&${dataObject[key]}`;
    });

    const hmac = crypto.createHmac('sha256', integritySalt);
    hmac.update(stringToHash);
    return hmac.digest('hex');
}


// --- EASYPAISA HELPER ---
function getEasypaisaSecureHash(dataObject) {
    const hashKey = process.env.EASYPAISA_HASH_KEY;

    // Filter out empty values and sort keys alphabetically
    const sortedKeys = Object.keys(dataObject).filter(key => dataObject[key] !== '' && dataObject[key] !== null).sort();

    let stringToHash = '';
    sortedKeys.forEach((key, index) => {
        stringToHash += `${key}=${dataObject[key]}${index < sortedKeys.length - 1 ? '&' : ''}`;
    });

    const hmac = crypto.createHmac('sha256', hashKey);
    hmac.update(stringToHash);
    return Buffer.from(hmac.digest('hex')).toString('base64');
}

module.exports = {
    getJazzCashSecureHash,
    getEasypaisaSecureHash
};