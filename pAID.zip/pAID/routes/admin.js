// routes/admin.js
const express = require('express');
const router = express.Router();
const path = require('path');
const bcrypt = require('bcrypt');
const fs = require('fs');
const { getDb } = require('../database');
const db = getDb();

// --- THE ONE AND ONLY UPLOAD CONFIGURATION ---
// This imports the robust uploader from our separate config file.
const upload = require('../setup/multer-config');

const saltRounds = 10;

// --- Authentication Middleware ---
function authMiddleware(req, res, next) {
    if (req.session.isAdmin) {
        return next();
    }
    return res.redirect('/admin/login');
}

// --- Admin Login/Logout/Dashboard Routes ---
router.get('/login', (req, res) => {
    if (req.session.isAdmin) { return res.redirect('/admin/dashboard'); }
    res.render('admin/login', { title: 'Admin Login', error: null });
});

router.post('/login', (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) { return res.render('admin/login', { title: 'Admin Login', error: 'Email and password are required.' });}
    const admin = db.prepare('SELECT * FROM admins WHERE username = ?').get(email);
    if (!admin) { return res.render('admin/login', { title: 'Admin Login', error: 'Invalid credentials' });}
    bcrypt.compare(password, admin.password, (err, result) => {
        if (err) { console.error("Bcrypt compare error:", err); return res.status(500).send("An internal error occurred.");}
        if (result === true) { req.session.isAdmin = true; return res.redirect('/admin/dashboard');
        } else { return res.render('admin/login', { title: 'Admin Login', error: 'Invalid credentials' }); }
    });
});

router.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) { return res.status(500).send("Could not log out."); }
        res.redirect('/admin/login');
    });
});

router.get('/dashboard', authMiddleware, (req, res) => {
    const products = db.prepare('SELECT * FROM products ORDER BY createdAt DESC').all();
    const orders = db.prepare('SELECT * FROM orders ORDER BY ordered_at DESC LIMIT 10').all();
    const totalProducts = db.prepare('SELECT COUNT(id) as count FROM products').get().count;
    const totalOrders = db.prepare('SELECT COUNT(id) as count FROM orders').get().count;
    const totalRevenue = db.prepare('SELECT SUM(total_amount) as total FROM orders').get().total || 0;
    res.render('admin/dashboard', {
        title: 'Admin Dashboard', products, orders,
        stats: { products: totalProducts, orders: totalOrders, revenue: totalRevenue.toFixed(2) }
    });
});

// --- Product CRUD Routes ---

// GET Add Product Form
router.get('/add-product', authMiddleware, (req, res) => {
    res.render('admin/product-form', { title: 'Add Product', product: null });
});

// POST Add Product (Uses the imported 'upload' middleware)
router.post('/add-product', authMiddleware, upload, (req, res) => {
    const { name, description, price, isDigital } = req.body;
    const isDigitalBool = parseInt(isDigital) === 1;

    const imageFile = req.files['productImage'] ? req.files['productImage'][0] : null;
    const digitalFile = req.files['digitalFile'] ? req.files['digitalFile'][0] : null;

    if (!imageFile) {
        return res.status(400).send('Product display image is required.');
    }
    if (isDigitalBool && !digitalFile) {
        return res.status(400).send('A digital file is required for a digital product.');
    }

    const imageUrl = `/uploads/${imageFile.filename}`;
    const digitalFilePath = isDigitalBool ? `/digital_files/${digitalFile.filename}` : null;

    const stmt = db.prepare(`
        INSERT INTO products (name, description, price, imageUrl, isDigital, digitalFilePath)
        VALUES (?, ?, ?, ?, ?, ?)
    `);
    stmt.run(name, description, parseFloat(price), imageUrl, isDigitalBool ? 1 : 0, digitalFilePath);

    res.redirect('/admin/dashboard');
});

// GET Edit Product Form
router.get('/edit-product/:id', authMiddleware, (req, res) => {
    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
    if (product) {
        res.render('admin/product-form', { title: 'Edit Product', product });
    } else {
        res.redirect('/admin/dashboard');
    }
});

// POST Edit Product
router.post('/edit-product/:id', authMiddleware, upload, (req, res) => {
    console.log("Edit product functionality needs to be fully implemented for digital files.");
    res.redirect('/admin/dashboard');
});

// POST Delete Product
router.post('/delete-product/:id', authMiddleware, (req, res) => {
    const product = db.prepare('SELECT imageUrl, digitalFilePath FROM products WHERE id = ?').get(req.params.id);

    if (product) {
        if (product.imageUrl) {
            const imagePath = path.join(__dirname, '../public', product.imageUrl);
            if (fs.existsSync(imagePath)) {
                fs.unlink(imagePath, (err) => { if (err) console.error("Error deleting image file:", err); });
            }
        }
        if (product.digitalFilePath) {
            const digitalPath = path.join(__dirname, '../public', product.digitalFilePath);
            if (fs.existsSync(digitalPath)) {
                fs.unlink(digitalPath, (err) => { if (err) console.error("Error deleting digital file:", err); });
            }
        }
    }
    db.prepare('DELETE FROM products WHERE id = ?').run(req.params.id);
    res.redirect('/admin/dashboard');
});

// --- Admin Setup Route ---
router.get('/setup-admin', (req, res) => {
    const username = 'admin@gmail.com'; const password = 'Admin123';
    const existingAdmin = db.prepare('SELECT * FROM admins WHERE username = ?').get(username);
    if (existingAdmin) { return res.send('<h1>Admin user with this email already exists.</h1>'); }
    bcrypt.hash(password, saltRounds, (err, hash) => {
        if (err) { console.error("Bcrypt hash error:", err); return res.status(500).send("Error hashing password."); }
        db.prepare('INSERT INTO admins (username, password) VALUES (?, ?)').run(username, hash);
        res.send(`<h1>Admin user created successfully!</h1><b>CRITICAL: You MUST now comment out this '/setup-admin' route.</b>`);
    });
});

module.exports = router;