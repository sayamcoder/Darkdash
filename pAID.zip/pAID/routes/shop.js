// routes/shop.js
const express = require('express');
const router = express.Router();
const path = require('path');
const { getDb } = require('../database');
const db = getDb();

// Home Page - Display all products
router.get('/', (req, res) => {
    try {
        const products = db.prepare('SELECT * FROM products ORDER BY createdAt DESC').all();
        res.render('index', { title: 'SpaceCafe', products });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// Product Detail Page
router.get('/product/:id', (req, res) => {
    try {
        const product = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
        if (product) {
            res.render('product', { title: product.name, product });
        } else {
            res.status(404).render('404', { title: 'Product not found' });
        }
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// Cart Page
router.get('/cart', (req, res) => {
    res.render('cart', { title: 'Shopping Cart' });
});

// --- UPDATED PAYMENT STATUS PAGES ---

// Payment Success Page
router.get('/payment/success', (req, res) => {
    const sessionId = req.query.session_id;
    if (!sessionId) {
        return res.render('payment-cancel', { title: 'Payment Error', message: 'No session ID provided.' });
    }

    stripe.checkout.sessions.listLineItems(sessionId, { limit: 100 }, (err, lineItems) => {
        if (err || !lineItems) {
            console.error("Stripe line items error:", err);
            return res.render('payment-cancel', { title: 'Payment Error', message: 'Could not retrieve order details.' });
        }
        
        const productNames = lineItems.data.map(item => item.description);
        if (productNames.length === 0) {
            return res.render('payment-success', { title: 'Payment Successful', purchasedProducts: [], sessionId });
        }
        
        const placeholders = productNames.map(() => '?').join(',');
        const products = db.prepare(`
            SELECT id, name, isDigital, digitalFilePath 
            FROM products WHERE name IN (${placeholders}) AND isDigital = 1
        `).all(productNames);
        
        res.render('payment-success', { 
            title: 'Payment Successful',
            purchasedProducts: products,
            sessionId: sessionId
        });
    });
});

// Payment Cancel Page
router.get('/payment/cancel', (req, res) => {
    res.render('payment-cancel', { title: 'Payment Canceled', message: 'Your order was not processed.' });
});

// --- NEW SECURE DOWNLOAD ROUTE ---
router.get('/download/:productId/:sessionId', (req, res) => {
    const { productId, sessionId } = req.params;

    const order = db.prepare('SELECT * FROM orders WHERE stripe_session_id = ?').get(sessionId);
    if (!order) {
        return res.status(403).send('Invalid purchase session. Access denied.');
    }

    const product = db.prepare('SELECT digitalFilePath FROM products WHERE id = ? AND isDigital = 1').get(productId);
    if (!product || !product.digitalFilePath) {
        return res.status(404).send('Digital product not found or file is missing.');
    }
    
    const filePath = path.join(__dirname, '../public', product.digitalFilePath);
    res.download(filePath, (err) => {
        if (err) {
            console.error("File download error:", err);
            if (!res.headersSent) {
                res.status(500).send('Could not download the file due to a server error.');
            }
        }
    });
});

// NEW API ROUTE TO SAVE CART TO SESSION
router.post('/api/save-cart-to-session', (req, res) => {
    // Get cart from the request body and save it to the user's session
    req.session.cart = req.body.cart;
    res.status(200).json({ message: 'Cart saved' });
});

module.exports = router;