// routes/payment.js
const express = require('express');
const router = express.Router();
const { getDb } = require('../database');
const { getJazzCashSecureHash, getEasypaisaSecureHash } = require('../setup/payment-helpers');
const db = getDb();

// This middleware will grab the cart from the session storage
// which our frontend will save before redirecting here.
router.use((req, res, next) => {
    if (req.session.cart) {
        req.cart = req.session.cart;
        delete req.session.cart; // Clear it after use
    }
    next();
});

// --- ROUTE 1: PREPARE FOR JAZZCASH ---
router.get('/jazzcash-checkout', (req, res) => {
    if (!req.cart) {
        return res.status(400).send("Cart not found.");
    }
    
    const cart = req.cart;
    const totalAmount = Math.round(cart.reduce((sum, item) => sum + item.price * item.quantity, 0));
    const orderRef = "JC-" + Date.now(); // Unique order reference

    const formData = {
        pp_Version: "2.0",
        pp_TxnType: "MWALLET",
        pp_Language: "EN",
        pp_MerchantID: process.env.JAZZCASH_MERCHANT_ID,
        pp_SubMerchantID: "",
        pp_Password: process.env.JAZZCASH_PASSWORD,
        pp_BankID: "",
        pp_ProductID: "",
        pp_TxnRefNo: orderRef,
        pp_Amount: totalAmount * 100, // Amount in paisa/cents
        pp_TxnCurrency: "PKR",
        pp_TxnDateTime: new Date().toISOString().slice(0, 19).replace(/-/g, "").replace(/:/g, "").replace("T", ""),
        pp_BillReference: "billref",
        pp_Description: "Payment for products from ModernShop",
        pp_TxnExpiryDateTime: "",
        pp_ReturnURL: `${process.env.BASE_URL}/payment/callback`,
        pp_SecureHash: "",
        ppmpf_1: "",
        ppmpf_2: "",
        ppmpf_3: "",
        ppmpf_4: "",
        ppmpf_5: "",
    };
    
    formData.pp_SecureHash = getJazzCashSecureHash(formData);

    // Instead of JSON, we render a view that will auto-submit a form
    res.render('redirect-to-payment', {
        title: 'Redirecting to JazzCash...',
        postURL: process.env.JAZZCASH_POST_URL,
        formData: formData
    });
});


// --- ROUTE 2: PREPARE FOR EASYPAISA ---
router.get('/easypaisa-checkout', (req, res) => {
    if (!req.cart) {
        return res.status(400).send("Cart not found.");
    }
    
    const cart = req.cart;
    const totalAmount = cart.reduce((sum, item) => sum + item.price * item.quantity, 0).toFixed(2);
    const orderRef = "EP-" + Date.now();

    const formData = {
        storeId: process.env.EASYPAISA_STORE_ID,
        amount: totalAmount,
        postBackURL: `${process.env.BASE_URL}/payment/callback`,
        orderRefNum: orderRef,
        // Optional fields
        expiryDate: new Date(Date.now() + 1 * 60 * 60 * 1000).toISOString().slice(0, 19).replace(/-/g, "").replace(/:/g, "").replace("T", ""),
        merchantPaymentMethod: "",
        emailAddress: "",
        mobileNum: ""
    };

    formData.autoRedirect = '1';
    formData.paymentMethod = 'MWALLET_PAYMENT_METHOD';
    formData.hashKey = getEasypaisaSecureHash(formData);
    
    // Auto-redirect is handled by Easypaisa if the parameter is set, but we still use our form.
    res.render('redirect-to-payment', {
        title: 'Redirecting to Easypaisa...',
        postURL: process.env.EASYPAISA_POST_URL,
        formData: formData
    });
});

// --- ROUTE 3: HANDLE CALLBACK/IPN from Gateways ---
router.post('/callback', (req, res) => {
    console.log("--- Payment Callback Received ---");
    console.log("Body:", req.body);

    // Here you would add logic to verify the response hash from JazzCash/Easypaisa
    // and then update your order status in the database.
    // For now, we'll just redirect to a generic success page.

    // Example verification for JazzCash:
    if (req.body.pp_ResponseCode === '000') {
        console.log("JazzCash Payment Successful for order:", req.body.pp_TxnRefNo);
        // TODO: Save order to DB here
    }

    // Example for Easypaisa:
    if (req.body.authResponse === '0000') {
        console.log("Easypaisa Payment Successful for order:", req.body.orderRefNum);
        // TODO: Save order to DB here
    }

    res.redirect('/payment/success');
});

module.exports = router;