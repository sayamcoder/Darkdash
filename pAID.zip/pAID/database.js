// database.js
const Database = require('better-sqlite3');

let db;

function initializeDatabase() {
    // Using a new filename to ensure a fresh start
    db = new Database('shop_digital_v1.db', { verbose: console.log });
    console.log('Database connected successfully.');

    // Create Admins table
    db.exec(`
        CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    `);

    // --- UPDATED PRODUCTS TABLE ---
    db.exec(`
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT NOT NULL,
            price REAL NOT NULL,
            imageUrl TEXT NOT NULL,
            isDigital BOOLEAN NOT NULL DEFAULT 0, -- 0 for false, 1 for true
            digitalFilePath TEXT,                 -- Path to the downloadable file
            createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // Create Orders table
    db.exec(`
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            stripe_session_id TEXT NOT NULL UNIQUE,
            customer_email TEXT NOT NULL,
            products_ordered TEXT NOT NULL,
            total_amount REAL NOT NULL,
            status TEXT,
            ordered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    `);
    console.log('Database tables verified/created.');

    // Defensive script to add the 'status' column to an existing 'orders' table
    try {
        db.exec('ALTER TABLE orders ADD COLUMN status TEXT');
        console.log("SUCCESS: 'status' column added to orders table.");
    } catch (error) {
        if (error.message.includes("duplicate column name")) {
            console.log("INFO: 'status' column already exists in orders table.");
        } else {
            console.error("Error altering table:", error.message);
        }
    }
}

function getDb() {
    if (!db) throw new Error("Database has not been initialized!");
    return db;
}

module.exports = { initializeDatabase, getDb };