// server.js

// --- 1. REQUIRE MODULES ---
require('dotenv').config();
const express = require('express');
const path = require('path');
const session = require('express-session');
const favicon = require('serve-favicon'); // Require the favicon package

// --- 2. INITIALIZE DATABASE ---
// This ensures the database is ready before any routes are loaded.
const { initializeDatabase } = require('./database');
initializeDatabase();

// --- 3. CREATE EXPRESS APP ---
const app = express();
const PORT = process.env.PORT || 3000;

// --- 4. SETUP MIDDLEWARE ---

// Use the favicon middleware right away.
// It needs the full, absolute path to your icon file.
// The path.join() method creates this path safely.
// IMPORTANT: Make sure 'favicon.ico' exists in your 'public' folder.
app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));

// The Stripe Webhook route needs the raw request body, so it comes
// before express.json() which would parse it. We will keep this structure
// even though we are not using Stripe, in case you switch back.
// (Note: This is not currently used by the Easypaisa/JazzCash flow).
const paymentRoutes = require('./routes/payment');

// Set the view engine to EJS
app.set('view engine', 'ejs');

// Serve static files (CSS, JS, images) from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Middleware to parse URL-encoded bodies (from form submissions)
// This is very important for the Easypaisa/JazzCash callback.
app.use(express.urlencoded({ extended: true }));

// Middleware to parse JSON bodies (from API requests)
app.use(express.json());

// Session middleware for admin logins and temporary cart storage
app.use(session({
    secret: 'a-super-secret-key-that-you-should-change-later',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Set to true if you deploy with HTTPS
}));

// --- 5. DEFINE ROUTES ---
const shopRoutes = require('./routes/shop');
const adminRoutes = require('./routes/admin');
// Note: paymentRoutes was already required above for the webhook.

app.use('/', shopRoutes);
app.use('/admin', adminRoutes);
app.use('/payment', paymentRoutes); // Use the main payment routes

// --- 6. HANDLE 404 NOT FOUND ---
// This runs if no other route matches the request.
app.use((req, res, next) => {
    res.status(404).render('404', { title: 'Page Not Found' });
});

// --- 7. GLOBAL ERROR HANDLER ---
// This is a special middleware that catches any errors passed with next(error).
app.use((err, req, res, next) => {
    console.error("--- AN UNCAUGHT ERROR OCCURRED ---");
    console.error(err.stack); // Log the full error stack for debugging
    // Ensure we don't try to send a response if one has already been sent
    if (!res.headersSent) {
        res.status(500).send('An unexpected server error occurred. Please try again later.');
    }
});

// --- 8. START THE SERVER ---
app.listen(PORT, () => {
    console.log(`Server is running successfully at http://localhost:${PORT}`);
});